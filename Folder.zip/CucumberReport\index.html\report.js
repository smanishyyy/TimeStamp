$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/java/com/snow/feature/STRY0020960.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: Jose Yamin"
    },
    {
      "line": 2,
      "value": "#Short description: Fix for INC03252680 - When requesting Off Catalog Item service, there should be an option to Ship To a user\u0027s address instead of just Shipping to a Stockroom"
    },
    {
      "line": 3,
      "value": "#Sprint: 2019 Open Incident Stories (2019-12-08)"
    },
    {
      "line": 4,
      "value": "#Release: ServiceNow - Stories for Incidents"
    }
  ],
  "line": 6,
  "name": "Fix for INC03252680 - When requesting Off Catalog Item service, there should be an option to Ship To a user\u0027s address instead of just Shipping to a Stockroom",
  "description": "",
  "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 78,
  "name": "Verify the user is able to submit the request with item \"Off Catalog Item (Canada, US)\"",
  "description": "",
  "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom;verify-the-user-is-able-to-submit-the-request-with-item-\"off-catalog-item-(canada,-us)\"",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 77,
      "name": "@Fourth"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 79,
      "value": "#STRY0020960_TC01_VerifyDropdown"
    }
  ],
  "line": 80,
  "name": "User logged into Service Now Portal",
  "keyword": "Given "
});
formatter.step({
  "line": 81,
  "name": "Clicks on Request service link on the home page",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 82,
      "value": "#And get the data from sheet as \"\u003crow_Index\u003e\" and column anme as \"\u003cColumnName\u003e\""
    }
  ],
  "line": 83,
  "name": "user select the requested for as with index \"\u003cRequested for\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 84,
  "name": "User gets select the country as \"\u003cCountry\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 85,
  "name": "user search the item \"\u003cItem\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 86,
  "name": "Click on the Item link",
  "keyword": "And "
});
formatter.step({
  "line": 87,
  "name": "Verify the title \"\u003cItem\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 88,
  "name": "Fill all the mandatory fields",
  "keyword": "And "
});
formatter.step({
  "line": 89,
  "name": "click on add cart button and submit the request for HP Item \"\u003cScreenhsotFoldername\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 90,
  "name": "store the tciket number in sheet for row as \"\u003crow_Index\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 91,
  "name": "User launch the IETL view and search the request",
  "keyword": "And "
});
formatter.examples({
  "line": 93,
  "name": "",
  "description": "Examples:",
  "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom;verify-the-user-is-able-to-submit-the-request-with-item-\"off-catalog-item-(canada,-us)\";",
  "rows": [
    {
      "cells": [
        "Requested for",
        "Country",
        "Item",
        "ScreenhsotFoldername"
      ],
      "line": 95,
      "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom;verify-the-user-is-able-to-submit-the-request-with-item-\"off-catalog-item-(canada,-us)\";;1"
    },
    {
      "cells": [
        "poddepa",
        "Canada",
        "Off Catalog Item (Canada, US)",
        "STRY0020960_TC04"
      ],
      "line": 96,
      "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom;verify-the-user-is-able-to-submit-the-request-with-item-\"off-catalog-item-(canada,-us)\";;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 7299700,
  "status": "passed"
});
formatter.scenario({
  "line": 96,
  "name": "Verify the user is able to submit the request with item \"Off Catalog Item (Canada, US)\"",
  "description": "Examples:",
  "id": "fix-for-inc03252680---when-requesting-off-catalog-item-service,-there-should-be-an-option-to-ship-to-a-user\u0027s-address-instead-of-just-shipping-to-a-stockroom;verify-the-user-is-able-to-submit-the-request-with-item-\"off-catalog-item-(canada,-us)\";;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 77,
      "name": "@Fourth"
    }
  ]
});
formatter.step({
  "comments": [
    {
      "line": 79,
      "value": "#STRY0020960_TC01_VerifyDropdown"
    }
  ],
  "line": 80,
  "name": "User logged into Service Now Portal",
  "keyword": "Given "
});
formatter.step({
  "line": 81,
  "name": "Clicks on Request service link on the home page",
  "keyword": "When "
});
formatter.step({
  "comments": [
    {
      "line": 82,
      "value": "#And get the data from sheet as \"\u003crow_Index\u003e\" and column anme as \"\u003cColumnName\u003e\""
    }
  ],
  "line": 83,
  "name": "user select the requested for as with index \"poddepa\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 84,
  "name": "User gets select the country as \"Canada\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 85,
  "name": "user search the item \"Off Catalog Item (Canada, US)\"",
  "matchedColumns": [
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 86,
  "name": "Click on the Item link",
  "keyword": "And "
});
formatter.step({
  "line": 87,
  "name": "Verify the title \"Off Catalog Item (Canada, US)\"",
  "matchedColumns": [
    2
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 88,
  "name": "Fill all the mandatory fields",
  "keyword": "And "
});
formatter.step({
  "line": 89,
  "name": "click on add cart button and submit the request for HP Item \"STRY0020960_TC04\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 90,
  "name": "store the tciket number in sheet for row as \"\u003crow_Index\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 91,
  "name": "User launch the IETL view and search the request",
  "keyword": "And "
});
formatter.match({
  "location": "ReusableStepDefFile.User_logged_into_Service_Now_Portal()"
});
formatter.result({
  "duration": 20536629400,
  "status": "passed"
});
formatter.match({
  "location": "ReusableStepDefFile.Clicks_on_Request_service_link_on_the_home_page()"
});
formatter.result({
  "duration": 752061300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "poddepa",
      "offset": 45
    }
  ],
  "location": "ReusableStepDefFile.user_select_the_requested_for_Index(String)"
});
formatter.result({
  "duration": 5315963800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Canada",
      "offset": 33
    }
  ],
  "location": "ReusableStepDefFile.User_gets_select_the_country_and_searches_to_the_Item(String)"
});
formatter.result({
  "duration": 10162252600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Off Catalog Item (Canada, US)",
      "offset": 22
    }
  ],
  "location": "ReusableStepDefFile.user_search_the_item(String)"
});
formatter.result({
  "duration": 3818587800,
  "status": "passed"
});
formatter.match({
  "location": "ReusableStepDefFile.Click_on_the_Item_link()"
});
formatter.result({
  "duration": 6189572400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Off Catalog Item (Canada, US)",
      "offset": 18
    }
  ],
  "location": "ReusableStepDefFile.Verify_The_Form_title(String)"
});
formatter.result({
  "duration": 5170818200,
  "status": "passed"
});
formatter.match({
  "location": "TC01_STRY0021103.fill_all_the_mandatory_fields()"
});
formatter.result({
  "duration": 10733026700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "STRY0020960_TC04",
      "offset": 61
    }
  ],
  "location": "ReusableStepDefFile.click_on_add_cart_button_and_submit_the_request(String)"
});
formatter.result({
  "duration": 136061000,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: Element \u003cbutton tabindex\u003d\"0\" ng-if\u003d\"c.showAddCartBtn()\" name\u003d\"add_to_cart\" ng-disabled\u003d\"submitting || submitted\" ng-click\u003d\"triggerAddToCart()\" class\u003d\"btn btn-default sc-btn form-control ng-scope\"\u003e...\u003c/button\u003e is not clickable at point (1102, 230). Other element would receive the click: \u003cdiv id\u003d\"select2-drop-mask\" class\u003d\"select2-drop-mask\" style\u003d\"display: block;\"\u003e\u003c/div\u003e\n  (Session info: chrome\u003d78.0.3904.108)\n  (Driver info: chromedriver\u003d2.39.562718 (9a2698cba08cf5a471a29d30c8b3e12becabb0e9),platform\u003dWindows NT 10.0.17763 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027VBX00245\u0027, ip: \u002710.232.175.150\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.39.562718 (9a2698cba08cf5..., userDataDir: C:\\Users\\chaurma\\AppData\\Lo...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 78.0.3904.108, webStorageEnabled: true}\nSession ID: 484d9dda009e58a40f020c056db93e5e\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy17.click(Unknown Source)\r\n\tat com.snow.pages.HPPrinterItemObj.ClickOn_AddCartButton(HPPrinterItemObj.java:42)\r\n\tat ReusableStepDefinitionFile.ReusableStepDefFile.click_on_add_cart_button_and_submit_the_request(ReusableStepDefFile.java:219)\r\n\tat ✽.And click on add cart button and submit the request for HP Item \"STRY0020960_TC04\"(src/main/java/com/snow/feature/STRY0020960.feature:89)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u003crow_Index\u003e",
      "offset": 45
    }
  ],
  "location": "ReusableStepDefFile.store_the_tciket_number_in_sheet_for_row_as(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ReusableStepDefFile.And_User_launch_the_IETL_view_and_search_the_request()"
});
formatter.result({
  "status": "skipped"
});
